import wikipedia
import json
import boto3

DISAMBIGUATION_KEYWORDS = []

def get_wiki_response(event, context):
    print("Event: " + str(event))
    event_body = event.get("body")
    print(get_wikipedia_summary("indian_culture"))
    if event_body is not None:
        print("Body: " + str(event_body))
        print(type(event_body))

        if isinstance(event_body, str):
            event_body = json.loads(event_body)
            


def get_wikipedia_summary(text, level=2):
        if text and level > 0:
            try:
                wiki_summary = wikipedia.summary(text)
                return wiki_summary
            except wikipedia.exceptions.DisambiguationError as disambiguationError:
                print("Disambiguation in Wikipedia occurred for {0}".format(text))
            except Exception as ex:
                print("An error occurred while trying to retrieve details from Wikipedia for {0}. Error details: {1}".format(text, str(ex)))

        return None

